import csv
import os 
import pandas as pd
from random import randint
from time import sleep
import datetime
from scihub import SciHub
import requests
import textwrap
import json

sh = SciHub()
def make_safe_filename(s):
    def safe_char(c):
        if c.isalnum():
            return c
        else:
            return "_"
    return "".join(safe_char(c) for c in s).rstrip("_")

parent_dir = "D:/SCOPUS/"
foldernama = 'D:/scihub/'
scopusAPIKEY= 'dac1df927a0265f01eee9ea53b5142cb'
df = pd.read_csv(foldernama + 'list_auto2.csv')
maxdownload = 25
years = ["1990", "2000", "2010", "2015","2018","2019"] 
now = datetime.datetime.now()
tahun = str(now.year)
filecsvError = 'error.csv'


if (os.path.exists(filecsvError)==False):
    fSubsetError = open(filecsvError, "w", newline='', encoding="utf-8")
    fError = csv.writer(fSubsetError)
    fError.writerow(["DOI", "Title","filename1"])
    fSubsetError.close()


for index, row in df.iterrows():
    print(row['folder'], row['keyword'], row['title'])
    directory = row['folder']
    path1 = os.path.join(parent_dir, directory) 
    try: 
        os.makedirs(path1, exist_ok = True) 
        #print("Directory '%s' created successfully" % directory) 
    except OSError as error: 
        print("Directory '%s' can not be created" % directory) 
    for year in years:
        print(year) 
        namafile = row['keyword'] + row['title']
        filecsv = foldernama + 'csv_auto/'+ namafile + '_' + year + '.csv'
        if (os.path.exists(filecsv)==False):
            sleep(randint(1,20))
            response = requests.get("https://api.elsevier.com/content/search/scopus?query=KEY("+ row['keyword'] +")%20AND%20title("+row['title']+")&apiKey=" + scopusAPIKEY + "&httpAccept=application/json&date="+ year +"-"+ tahun +"&sort=citedby-count")
            results  = json.loads(response.text)
            fSubset = open(filecsv, "w", newline='', encoding="utf-8")
            f = csv.writer(fSubset)
            f.writerow(["citedby", "DOI", "creator", "Title","year", "publicationName"])
            for r in results['search-results']["entry"]:
                try:
                    print([str(r['citedby-count'])],[str(r['prism:doi'])],[str(r['dc:creator'])],[str(r['dc:title'])],[str(r['prism:coverDate'])],[str(r['prism:publicationName'])])
                    f.writerow([str(r['citedby-count']),str(r['prism:doi']),str(r['dc:creator']),str(r['dc:title']),str(r['prism:coverDate']),str(r['prism:publicationName'])])
                except:
                    print('error')        
            fSubset.close()
            
        df1 = pd.read_csv(filecsv)
        for index1, row1 in df1.iterrows():
            if index1 > maxdownload:
                break
            title = make_safe_filename(row1['Title'])
            title = title[0:200]
            filename1 = path1 + "/" + title + ".pdf"
            filename1 = filename1.strip()
            #print(filename1)
            if (os.path.exists(filename1)==False):
                DOI = row1['DOI']
                if (pd.isnull(DOI)==False):
                    print(index1)
                    try: 
                        print(filename1)
                        df_cekerror = pd.read_csv(filecsvError)
                        if DOI in df_cekerror['DOI'].values:
                            print('Sering Error, File dilewati')
                            break
                        result = sh.download(DOI, path=filename1)
                        #print(result)
                        if (os.path.exists(filename1)==False):
                            print('error ditangkap1')
                            fSubsetError = open(filecsvError, "a", newline='', encoding="utf-8")
                            fError = csv.writer(fSubsetError)
                            fError.writerow([str(row1['DOI']),str(row1['Title']),str(filename1)])
                            fSubsetError.close()
                        sleep(randint(5,10))
                    except: 
                        print("PDF '%s' can not be downloaded" % filename1) 

